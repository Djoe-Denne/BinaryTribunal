<p align="center">
  <img src="social-preview.png" alt="OpenCode Ensemble - Parallel agents. One coordinated team." width="100%">
</p>

# OpenCode Ensemble

[![npm version](https://img.shields.io/npm/v/@hueyexe/opencode-ensemble.svg)](https://www.npmjs.com/package/@hueyexe/opencode-ensemble)
[![npm downloads](https://img.shields.io/npm/dm/@hueyexe/opencode-ensemble.svg)](https://www.npmjs.com/package/@hueyexe/opencode-ensemble)
[![CI](https://github.com/hueyexe/opencode-ensemble/actions/workflows/ci.yml/badge.svg)](https://github.com/hueyexe/opencode-ensemble/actions/workflows/ci.yml)
[![TypeScript](https://img.shields.io/badge/TypeScript-strict-blue.svg)]()
[![deps](https://img.shields.io/badge/deps-runtime%3A%20OpenCode%20SDKs-blue.svg)]()
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)

Run parallel AI agents in OpenCode. Each agent gets its own session, context window, and task. They coordinate through messaging and a shared task board.

Built on the public OpenCode SDKs — no OpenCode internals. Runtime dependencies are the three OpenCode SDK packages (`@opencode-ai/sdk`, `@opencode-ai/plugin`, `@opencode/plugin`). The bundled TUI companion additionally uses SolidJS and OpenTUI, provided by the OpenCode host and declared as peer dependencies.

## Quick Start

Install the plugin and you're done:

```sh
opencode plugin add @hueyexe/opencode-ensemble@0.18.0
```

Then restart OpenCode and ask it to do something that benefits from parallel work. The agent handles the rest. See [Install](#install) for worktree permissions and other options.

## What actually happens

You ask the agent to do something complex. It creates a team, spawns teammates, and they work in parallel. Each teammate runs in its own OpenCode session with a fresh context window.

A realistic development-team interaction:

```
You: "Fix checkout idempotency so duplicate Stripe webhooks cannot create
duplicate orders. Add regression tests and review the final diff for risk."

The lead agent:
1. Creates a team called "checkout-idempotency".
2. Adds independent tasks first and records the generated task IDs.
3. Adds dependent QA and review tasks with `depends_on` using real returned IDs.
4. Spawns a small team with explicit roles:
   - scout: explore agent, worktree disabled, model openai/gpt-5-mini (example)
   - api-dev: build agent, own worktree, model anthropic/claude-opus-4-7 (example), plan_approval: true
   - qa: build agent, own worktree, model anthropic/claude-opus-4-7 (example)
   - reviewer: explore agent, worktree disabled, model openai/gpt-5-mini (example)
```

The lead uses the task board to make sequencing visible. Record the returned task IDs before creating dependent tasks:

```ts
team_tasks_add({
  tasks: [
    { content: "Map checkout webhook flow and identify idempotency risks", priority: "high" },
    { content: "Implement duplicate-webhook idempotency guard", priority: "high" },
  ],
})
// -> Added 2 tasks: task_abc123, task_def456

team_tasks_add({
  tasks: [
    { content: "Add regression tests for duplicate webhook delivery", priority: "high", depends_on: ["task_def456"] },
  ],
})
// -> Added 1 task: task_ghi789

team_tasks_add({
  tasks: [
    { content: "Review final diff for order, payment, and retry risks", priority: "medium", depends_on: ["task_def456", "task_ghi789"] },
  ],
})
// -> Added 1 task: task_jkl012
```

Then it spawns teammates one at a time:

```ts
team_spawn({
  name: "scout",
  agent: "explore",
  worktree: false,
  model: "openai/gpt-5-mini",
  claim_task: "task_abc123",
  prompt: "Trace the checkout webhook flow. Report the files, data model, existing tests, and the smallest safe implementation plan. Do not edit files.",
})

team_spawn({
  name: "api-dev",
  agent: "build",
  model: "anthropic/claude-opus-4-7",
  plan_approval: true,
  claim_task: "task_def456",
  prompt: "After scout reports, implement the idempotency guard. Keep the change narrow. Commit your work and send a task-result message.",
})
```

The same pattern assigns `qa` to regression tests and `reviewer` to final review. The reviewer stays read-only (`worktree: false`) so it can inspect merged changes without producing another branch.

Teammates coordinate without the lead polling:

```
scout -> lead: "Checkout flow is src/webhooks/stripe.ts -> createOrderFromPayment(). Existing tests are in test/checkout-webhook.test.ts. Risk: retries race before order insert commits."
api-dev -> lead: "Plan ready: add unique event_id insert before order creation, treat duplicate insert as success, add a transaction around order creation."
lead -> api-dev: approves plan
qa -> api-dev: "Which duplicate signal should tests assert: event_id conflict or existing order lookup?"
api-dev -> qa: "Assert duplicate event_id returns success and creates one order. See src/webhooks/stripe.ts."
```

When work is done, the lead reviews and integrates deliberately:

```
team_results({ from: "api-dev" })
team_shutdown({ member: "api-dev" })
team_merge({ member: "api-dev" })

team_results({ from: "qa" })
team_shutdown({ member: "qa" })
team_merge({ member: "qa" })

team_spawn({ name: "reviewer", agent: "explore", worktree: false, claim_task: "task_jkl012", prompt: "Review the merged diff for correctness, missed tests, and risky behavior. Do not edit files." })
```

The lead runs the repository verification commands, summarizes the result, and only then cleans up the team. All merged teammate changes remain in your working directory as unstaged changes for review with `git diff`.

## Agent Skill

Use the companion skill as the reusable operating guide: it helps choose useful teams, native context transitions, model strategy, bounded missions, and integration practices. Team size and profiles are chosen per mission; no explorer/architect/implementer sequence is required.

**For this local fork**, expose its `skills/` directory in your OpenCode V2 configuration, or copy the complete `skills/opencode-ensemble/` directory into your project's `.opencode/skills/`. Load the matching runtime plugin separately. This repository's root `opencode.json` already exposes the canonical skill when working from its root.

Add a short instruction to the project's `AGENTS.md` to load `opencode-ensemble` when teamwork is useful. Keep durable expertise and permissions in optional `.opencode/agents/*.md` profiles, and put task-specific ownership in spawn prompts. See the [project integration guide](skills/opencode-ensemble/references/project-integration.md) for copyable configuration, project policy, and an optional native agent profile. You can also explicitly request `@opencode-ensemble` in V2.

For **interactive installation**, use the companion [ensemble-project-setup](skills/ensemble-project-setup/README.md) skill:

```text
@ensemble-project-setup Analyze this project's existing agents and instructions.
Propose the smallest useful Ensemble integration for approval, preserving our
profiles, models, permissions, and flexible team composition.
```

It diagnoses the current setup, explains inferred preferences, proposes a diff, and applies approved changes. Repeat runs can produce no changes. Both skills are exposed by this repository's `skills/` source: `ensemble-project-setup` handles onboarding; `opencode-ensemble` handles team missions.

For the **published upstream skill**:

```bash
npx skills@latest add hueyexe/opencode-ensemble --skill opencode-ensemble
```

The upstream version may not yet include this fork's continuity features; keep skill and plugin versions aligned. Installing the skill alone does not install the plugin's tools.

Optional team shapes:

- **Scout, builder, reviewer**: one read-only `explore` agent maps the code, one `build` agent changes it, one read-only `explore` agent reviews the diff.
- **Parallel slices**: two or three `build` agents own independent files or vertical slices, then one reviewer checks the combined result.
- **Risky change**: use `plan_approval: true` on the implementing teammate, then approve or reject the plan through `team_message` before edits begin.
- **Shared research**: fork independent workers directly from an existing member's native history; give each only its new mission delta.
- **Same-session continuation**: use `team_handoff` when the current session needs another specialty, retaining its history, team role, directory, and model.

## Dashboard

A real-time mission control dashboard runs at `http://localhost:4747` while OpenCode is active.

![Ensemble Dashboard](docs/dashboard.png)

- **Health ring** — at-a-glance team health indicator in the header
- **Agent cards** — status, current task, activity sparklines, timing. Click to open detail drawer
- **Agent drawer** — full prompt, model, execution status, chat-style message history with markdown rendering
- **Task board** — progress bar, collapsible status groups, dependency arrows
- **Activity feed** — chat-style message bubbles with avatars, expandable with full markdown
- **Timeline** — horizontal event strip showing spawns, messages, completions, shutdowns
- **Keyboard shortcuts** — `j/k` navigate agents, `Enter` opens drawer, `Esc` closes, `?` shows help
- **Live clock** — current time + team session duration
- **Project outline** — collapsible per-project grouping when teams span multiple working directories

Configure the port in `.opencode/ensemble.json`:

```json
{
  "dashboardPort": 4747
}
```

Set to `0` to disable. The dashboard starts automatically when OpenCode loads the plugin.

## Install

Two steps: add the plugin, then allowlist worktree paths.

### Runtime requirements

The plugin uses SQLite via the host's runtime adapter:

- **Bun**: any version with `bun:sqlite` (Bun ≥ 1.0).
- **Node / Electron** (e.g. opencode Desktop): **Node ≥ 24** for stable `node:sqlite`. Older Node (20.x) lacks the module entirely; Node 22.5–23 has it behind `--experimental-sqlite`. If you load the plugin under an older Node and see `Cannot find module 'node:sqlite'` at startup, your runtime is too old.

### 1. Add the plugin

The simplest install is the CLI (npm registry or Git package specifiers both work):

```sh
opencode plugin add @hueyexe/opencode-ensemble@0.18.0
```

This installs globally and writes the config entry for you. To update later: `opencode plugin update @hueyexe/opencode-ensemble`.

**Manual config** — add to your OpenCode config with a pinned version. Project-level or global.

**Project-level** (`opencode.json` in your project root):

```jsonc
{
  // OpenCode v2:
  "plugins": ["@hueyexe/opencode-ensemble@0.18.0"]
}
```

**Global** (`~/.config/opencode/opencode.json`): same entry.

```jsonc
{
  // OpenCode v1:
  "plugin": ["@hueyexe/opencode-ensemble@0.18.0"]
}
```

OpenCode auto-installs npm plugins at startup. To update, bump the version number in your config and restart OpenCode.

**Why pin versions?** OpenCode has a [known bug](https://github.com/anomalyco/opencode/issues/6774) where unpinned plugins (e.g., `"@hueyexe/opencode-ensemble"`) get cached on first install and never auto-update, even after restarting. Pinning to a specific version avoids this — when you change the version string, OpenCode sees a new package spec and installs it fresh.

If you're stuck on an old version, clear the cache manually:

```bash
rm -rf ~/.cache/opencode/packages/@hueyexe
```

Then restart OpenCode.

### 2. Allow worktree directory access

Teammates work in git worktrees outside your project directory. Without this permission, OpenCode will prompt you to approve every file operation in a teammate's worktree.

Add to your OpenCode config (`~/.config/opencode/opencode.json`).

OpenCode v2 (`permissions` array):

```jsonc
{
  "permissions": [
    { "action": "external_directory", "resource": "~/.local/share/opencode/worktree/**", "effect": "allow" }
  ]
}
```

OpenCode v1 (`permission` map):

```json
{
  "permission": {
    "external_directory": {
      "~/.local/share/opencode/worktree/**": "allow"
    }
  }
}
```

This is required. Without it, you'll see "Permission required — Access external directory" prompts constantly.

### Local development

Configure the worktree as a local plugin (v2 loads the source entry; v1 uses the `server()` export from the same file):

```jsonc
{
  "plugins": [{ "package": "/path/to/opencode-ensemble" }]
}
```

No build step needed for local testing — but run `bun run typecheck && bun test && bun run build` before committing. Restart OpenCode (or wait for hot-reload) to pick up changes.

## Optional mission preparation

Simple `/ensemble-mission <objective>`, then `config`, then the user's `start`,
is unchanged. Optional discovery is
`/ensemble-mission prepare [--pm <agent>] <mandat>`. A new session requires the
mandate; an existing draft may omit it and keep the stored objective. After the
initial candidate and five PM corrections, only the lead may run
`/ensemble-mission prepare --accept <json>`. `--pm` and `--accept` are mutually
exclusive. The command runtime, generic intervention contract, and deterministic
import are implemented without a sixteenth team tool. The selected PM is an
existing native agent declared in category `pm`; Ensemble injects its discovery
contract without registering an agent or adding permissions. Public `session.prompt`
has no structured-output field, so the document is ordinary JSON. `start` remains
the execution gate. Field rules, examples, and counterexamples:
[preparation](docs/preparation.md).

## Tools

15 tools. Teammates can use messaging, tasks, inspection, and V2 `team_handoff` (10 tools); spawning, shutdown, and merging remain lead-only. V1 keeps the original 14 operations and reports an explicit unsupported-capability error for handoff or inherited spawning.

**Team lifecycle** (lead only, except archived-team purge may also be run from the main session)

| Tool | What it does |
|------|-------------|
| `team_create` | Create a team. Caller becomes the lead. Accepts optional `project_name` to label the project. |
| `team_spawn` | Start a new teammate with a task. Supports `plan_approval` and opt-in V2 context inheritance. |
| `team_shutdown` | Ask a teammate to stop. Preserves their branch before aborting. Supports `force` flag. |
| `team_merge` | Merge a shutdown teammate's branch into working directory (unstaged). Blocks if you have local changes to overlapping files. |
| `team_cleanup` | Remove the current team when done. Safety-net merges forgotten branches. With `purge`, previews archived-team deletion and returns exact approval labels plus a confirmation token. |
| `team_status` | See all members, their status, and a task summary. |
| `team_view` | Resolve a teammate's session; pass `navigate: true` to switch the TUI to it (opt-in — only when the user explicitly asks). |

Archived-team purge is intentionally two-step. First call `team_cleanup` with `purge` to get a preview, exact approval and denial option labels, and `confirm_token`; no data is deleted. Stale archived worktree/workspace references and stale Ensemble-owned branches are counted in the preview and cleaned during confirmed purge. Arbitrary non-Ensemble branches still block purge for safety. The lead must then use the question tool with those exact options. Only after the user selects the exact approval option should it call `team_cleanup` again with the same `purge`, `confirm_purge: true`, and the preview token.

**Communication** (everyone)

| Tool | What it does |
|------|-------------|
| `team_message` | Send a direct message to a teammate or the lead. Also handles plan approval/rejection. |
| `team_broadcast` | Message everyone on the team. |
| `team_results` | Retrieve full message content (messages to lead are truncated on delivery). |

**Task board** (everyone)

| Tool | What it does |
|------|-------------|
| `team_tasks_list` | See all tasks with status and assignee. |
| `team_tasks_add` | Add tasks to the shared board. |
| `team_tasks_complete` | Mark a task done. Unblocks dependents. |
| `team_claim` | Claim a pending task. Atomic, prevents double-claims. |

**Session continuity** (V2, any team member including the lead)

- `team_handoff({ agent })`: change the calling session's native agent for subsequent turns. Keeps the session ID, history, team role, tasks, and worktree.

## Session inheritance (V2)

Restrictive QA/reviewer profiles can set `report_mode: "final_response"` in
`team_spawn` to return a native candidate for lead review without gaining
team-tool permissions. Retrieval never completes tasks or releases dependencies;
the lead must review and integrate before closing the prerequisite. See
[Worker reporting and lead review](docs/worker-reporting.md).

`team_spawn` starts fresh unless `context` is supplied. To give a worker a scout's actual native history:

```javascript
await tools.team_spawn({
  name: "parser",
  agent: "build",
  prompt: "Implement the parser using the researched interfaces.",
  context: { mode: "fork", from: "scout" },
})
```

The modes are:

- **`fresh`**: an independent session; also the default when `context` is omitted.
- **`fork`**: fork the source's full projected native history, then append the new identity and task.
- **`checkpoint`**: fork before `messageID`, an **exclusive** native boundary. For history A/B/C/D/E, use D's ID to include C and exclude D/E.
- **`compact_fork`**: compact a distinct, idle source with OpenCode, verify its durable checkpoint completed, then fork the native summary and retained recent context.

`from` defaults to `"current"`; it also accepts `"lead"`, a member name, or a session ID belonging to this team. Finished members remain valid sources while their native sessions exist. Only the lead can spawn.

Inside the scout, `await tools.team_handoff({ agent: "plan" })` changes the agent in the **same session**, so research can become architecture without another spawn. Native agent selection preserves the session's selected model. The lead can change a teammate's model separately with `team_message({ to, model })`.

### Native fork connection

OpenCode 2.0.25/2.0.26 exposes `session.fork` over its public HTTP API but omits it from the plugin context. Configure the **same server** in `.opencode/ensemble.json`:

```json
{ "v2ApiUrl": "http://127.0.0.1:4096" }
```

Use your server's actual URL. `OPENCODE_ENSEMBLE_V2_API_URL` overrides this setting; `OPENCODE_ENSEMBLE_V2_AUTHORIZATION` supplies the complete Authorization header (for example, the server's Basic authorization value). Set these in the server process environment. The adapter verifies the source session's identity, project, creation time, and directory before forking. A host-provided `ctx.session.fork` takes precedence when available.

Inherited writers receive separate worktrees. The source and destination must be clean and at the same Git HEAD before a native move; otherwise spawning fails explicitly. The child is moved and its agent selected before its task is admitted. Initialization hooks prevent premature model execution. There is no silent replacement with a fresh session or shared-directory fallback for inherited spawns.

See the [continuity guide](docs/native-session-continuity.md) for the complete Explorer → Architect → three workers workflow, checkpoint examples, recovery, compatibility, validation results, and remaining limitations.

## What you see in the TUI

The plugin works within OpenCode's existing UI on every client (terminal, desktop, web): tools, approvals, messages, and the [dashboard](#dashboard) at `http://localhost:4747` all live server-side.

What you get:

- **Team state in context** — the lead's system prompt carries member statuses and task counts, so it stays aware across turns including after compaction.
- **Teammate messages** arriving in the lead's session as labeled blocks with the sender's name.
- **Rich tool titles** in the sidebar (e.g. "Spawned alice (build)", "Message -> bob", "Task board (3 tasks)").
- **Status checks** via `team_status` for a snapshot of the whole team.
- **Terminal extras** (terminal only): a sidebar widget with live member status and task counts via the bundled `./tui` companion, loaded automatically with the plugin. `team_view` reports the teammate session by default; ask for it and `navigate: true` switches the TUI there (ctrl+p to return).

## Architecture

- **SQLite** (WAL mode) for teams, members, tasks, and messages. Uses `bun:sqlite` in Bun and `node:sqlite` in Node/Electron through the internal database adapter.
- **promptAsync** for message delivery: injects a message and starts the prompt loop in one call
- **Git worktree isolation**: each teammate gets their own worktree by default, so multiple agents can edit files without conflicts. Opt out with `worktree: false` for read-only agents.
- **Automatic branch lifecycle**: if V2 creates a detached worktree, Ensemble verifies it belongs to the source repository and attaches a unique local branch without moving its commit. After a successful merge, it removes the worktree, then its checkout and safety branches locally and on configured remotes (if published). Remote deletion requires the exact expected commit and uses a lease: newer remote work, authentication failures, and removal failures keep cleanup pending and retain the safety reference for retry. Ensemble does not publish these temporary branches automatically. Merge results remain unstaged for review and must still be committed and pushed to `main` by the supervisor.
- **System prompt injection**: the lead's system prompt includes team state (member statuses, task counts) on every LLM call. Teammates get a short role reminder.
- **Compaction safety**: team context is preserved when OpenCode compacts long conversations
- **Native session continuity (V2)**: optional forks/checkpoints and same-session agent handoff, with persisted provenance and interrupted-spawn reconciliation
- **Shell environment**: teammate shells get `ENSEMBLE_TEAM`, `ENSEMBLE_MEMBER`, `ENSEMBLE_ROLE`, and `ENSEMBLE_BRANCH` variables
- **Sub-agent isolation**: teammates' sub-agents can't use team tools (parent chain tracking, max depth 10)
- **Crash recovery**: stale busy members marked as errored on restart, orphaned sessions aborted, orphaned worktrees cleaned up, undelivered messages redelivered
- **Spawn rollback**: if the initial prompt fails, the member, session, and worktree are all cleaned up
- **Timeout watchdog**: teammates stuck busy beyond the TTL are automatically timed out and aborted
- **Stall detection**: detects teammates making no progress (low output tokens or no communication) and escalates to the lead
- **Peer-to-peer communication**: teammates can message each other directly, with idle-flush delivery and chatty agent detection
- **Auto-merge on cleanup**: worktree branches are squash-merged into your working directory as unstaged changes for review
- **Overlap detection**: `team_merge` blocks when you have local changes to files the agent also modified, preventing silent overwrites
- **Spawn circuit breaker**: stops retrying after 3 consecutive spawn failures
- **Graceful shutdown**: busy teammates receive a shutdown message and finish their current work. Use `force: true` to abort immediately.
- **Rate limiting**: token bucket (configurable via config file or `OPENCODE_ENSEMBLE_RATE_LIMIT`, default 10 tokens/sec)

## Model Selection

Control which AI models your agents use. Without an Ensemble override, fresh spawns use OpenCode's native default and inherited spawns retain the source session's selected model. You can override this per-agent, per-agent-type, or with automatic rotation.

**All agents use the same model:**
```json
{
  "defaultModel": "anthropic/claude-sonnet-4-6"
}
```

**Different models for different agent types:**
```json
{
  "modelsByAgent": {
    "build": "anthropic/claude-opus-4-7",
    "explore": "openai/gpt-5.3-codex-spark"
  }
}
```

**Rotate through a pool for diverse perspectives:**
```json
{
  "modelPool": ["anthropic/claude-opus-4-7", "anthropic/claude-sonnet-4-6", "openai/gpt-5.4"],
  "modelAssignment": "rotate"
}
```

**Ask the user before spawning:**
```json
{
  "promptForModels": true,
  "modelPool": ["anthropic/claude-opus-4-7", "opencode/big-pickle", "openai/gpt-5.3-codex-spark"]
}
```

When `promptForModels` is true, the lead uses the question tool to ask which models to use before spawning any agents. The user can pick the same model for all agents, mix from the pool, or choose per agent.

**Resolution order** — when an agent is spawned, the model is determined by:
1. Explicit `model` param on `team_spawn` (lead or user chose it)
2. `modelsByAgent` mapping for this agent type
3. `modelAssignment` strategy (`rotate` or `random` from `modelPool`)
4. `defaultModel`
5. Native selection: OpenCode's default for fresh spawns; the source session's selected model for inherited spawns

The lead can override by passing `model` directly on `team_spawn`, regardless of config. An explicit override is a choice, not a requirement. Native `team_handoff` retains the existing selected model; use `team_message({ to, model })` to change a teammate's model separately.

Model IDs use the `provider/model` format from [models.dev](https://models.dev) (e.g. `anthropic/claude-opus-4-7`, `openai/gpt-5.4`). For OpenCode Zen models, use the `opencode/` prefix (e.g. `opencode/big-pickle`).

## Configuration

Configure via JSON files, environment variables, or both. Project config overrides global config. Env vars override everything.

### Config file

**Global** (`~/.config/opencode/ensemble.json`):

```json
{
  "mergeOnCleanup": true,
  "stallThresholdMs": 300000,
  "stallMinSteps": 5,
  "stallTokenThreshold": 200,
  "timeoutMs": 1800000,
  "rateLimitCapacity": 10,
  "dashboardPort": 4747,
  "defaultModel": "anthropic/claude-sonnet-4-6",
  "modelPool": ["anthropic/claude-opus-4-7", "anthropic/claude-sonnet-4-6", "openai/gpt-5.4"],
  "modelsByAgent": {},
  "modelAssignment": "default",
  "promptForModels": false
}
```

**Project** (`.opencode/ensemble.json` in your project root) — same shape, overrides global per-key.

All fields are optional. Missing fields use defaults.

| Key | Default | Description |
|-----|---------|-------------|
| `mergeOnCleanup` | `true` | Auto-merge worktree branches on cleanup (squash + unstage) |
| `stallThresholdMs` | `300000` (5 min) | Time without communication before stall escalation. `0` disables. |
| `stallMinSteps` | `5` | Min model steps before token-based stall check kicks in |
| `stallTokenThreshold` | `200` | Output tokens per step below which the agent is considered stalled |
| `timeoutMs` | `1800000` (30 min) | Hard timeout for busy teammates. `0` disables. |
| `rateLimitCapacity` | `10` | Token bucket capacity for team tool calls. `0` disables. |
| `dashboardPort` | `4747` | Dashboard server port. `0` disables. |
| `defaultModel` | `""` | Default model for all agents (e.g. `"anthropic/claude-sonnet-4-6"`). Empty = native selection (source selection for inherited sessions). |
| `modelPool` | `[]` | List of models for rotation/random assignment. |
| `modelsByAgent` | `{}` | Map agent type to model (e.g. `{"build": "anthropic/claude-opus-4-7"}`). |
| `modelAssignment` | `"default"` | How to assign models: `"default"`, `"rotate"`, or `"random"`. |
| `promptForModels` | `false` | Lead asks user about model preferences before spawning. |
| `v2ApiUrl` | `""` | Public API URL of the same V2 server, required for inherited spawns when the plugin host omits `session.fork`. |
| `maxActiveMembers` | `0` | Max members per team in non-terminal status (task pool cap). `0` = unlimited. Spawn refuses with an explicit error at the cap. |
| `autoDispatch` | `false` | Pull-based pool: when a member goes idle, push it the next eligible board task. Order: agent affinity (`@agent`) first, then priority, then FIFO. |
| `autoScale` | `false` | Spawn `pool-<N>` workers to fill `maxActiveMembers` while unassigned work remains. Agent type from task affinity; pair with `modelPool` + `modelAssignment: "rotate"` to spread across providers. |
| `modelRouting` | `{ "beta": 0.35, "models": [] }` | Deterministic minimum-cost routing from task complexity/risk and a scored model/effort catalogue. Explicit `model` wins; no scores preserves existing selection. |
| `missionPolicy` | `null` | Complete default 2D policy for command-prepared missions. Null seeds a reviewable draft from the available catalogue; approval is still required. |

### Declarative business profiles

Business profiles identify a kind of work, separately from an OpenCode native
agent's exact name and its Ensemble lead/member identity. The initial catalogue is:

- `supervisor` — mission coordination, scope arbitration, evidence and user decisions.
- `pm` — requirements, priorities, work decomposition and tracking.
- `architect` — contracts, boundaries and design decisions.
- `developer` — implementation and associated tests.
- `qa` — acceptance verification, reproduction and regression checks.
- `reviewer` — critical examination of changes, defects and risks.
- `researcher` — exploration, research and sourced evidence.
- `documentalist` — structuring, integrating and maintaining documentation and knowledge.

Configure explicit associations in **Ensemble's** `.opencode/ensemble.json`
(or `~/.config/opencode/ensemble.json`), not as a new OpenCode agent field:

```json
{
  "businessProfiles": {
    "extensions": {
      "security-reviewer": { "description": "Review security boundaries and threats" }
    },
    "byAgent": {
      "orchestrator": "supervisor",
      "implementer": "developer",
      "second-builder": "developer",
      "code-reviewer": "reviewer",
      "security-reader": "security-reviewer"
    }
  }
}
```

These native names are examples, not agents created or renamed by the plugin.
Each native agent has at most one declared principal profile; several agents may
share one. Associations are exact and case-sensitive: even an agent named `qa`
has no business profile unless explicitly mapped. Omitting `businessProfiles`,
`extensions` or `byAgent` adds no declarations and preserves existing execution.
Projects need not provide an agent for every catalogue entry.

Extensions use a lower-kebab-case ID matching `[a-z][a-z0-9]*(-[a-z0-9]+)*` and a
non-empty `description`. They cannot redefine an initial ID or contain execution
settings. Global and project `extensions` and `byAgent` merge **per entry**; the
project replaces same-key custom definitions and mappings. Empty maps do not
delete inherited entries. References are checked after merging, so an inherited
mapping can reference an extension supplied by the project. Malformed explicit
declarations and unknown profile references **block configuration loading with a
diagnostic** identifying the field and config paths; they never revive an old
mapping or substitute an agent. The existing invalid-JSON fallback is unchanged.

Profiles grant no permissions, select no model, change no native identity or
lead authority, and trigger no specialized behavior, automatic phases or QA/review
pipeline. In particular, `supervisor` and `pm` do not make an agent the Ensemble
lead. Model settings such as `modelsByAgent` still use native agent names.

For future consumers, `src/business-profiles.ts` provides the immutable
`INITIAL_BUSINESS_PROFILES` catalogue, `resolveBusinessProfilesConfig(...layers)`
and the pure `inspectAgentBusinessProfile(config, nativeName, evidence?)` helper.
The helper reports declaration (`declaredProfile`/`profile`), `diskPresence` and
`nativeAvailability` independently. Optional `evidence.diskAgents` and
`evidence.nativeAgents` are **complete name inventories obtained independently**
by the caller. Omit an inventory when it has not been checked: the result is
`unverified`, not absent or unavailable. A disk inventory can prove file presence
but never native availability; built-in or JSON-defined agents can be available
without a project Markdown file. Only supply `nativeAgents` from a verified native
inventory for the relevant host/location. This helper performs no filesystem scan
or host call, and its results/config copies do not mutate the shared catalogue.

### Environment variables

Env vars override config file values. Useful for CI or one-off overrides.

```bash
# Adjust teammate timeout (default: 1800000ms = 30 minutes)
OPENCODE_ENSEMBLE_TIMEOUT=3600000

# Disable timeout watchdog
OPENCODE_ENSEMBLE_TIMEOUT=0

# Adjust rate limit (default: 10 tokens, refills 2/sec)
OPENCODE_ENSEMBLE_RATE_LIMIT=20

# Disable rate limiting
OPENCODE_ENSEMBLE_RATE_LIMIT=0

# Adjust stall detection threshold (default: 300000ms = 5 minutes)
STALL_THRESHOLD_MS=300000

# Disable stall detection
STALL_THRESHOLD_MS=0

# Cap active members per team (task pool; default: 0 = unlimited)
OPENCODE_ENSEMBLE_MAX_MEMBERS=4
```

### Command-prepared missions (V2)

```text
/ensemble-mission Implement an isolated cache with compatibility tests
/ensemble-mission config
/ensemble-mission start
```

Prepare a mission, discuss providers and model choices in the chat, then approve
the presented policy with `start`. Each mission owns a versioned
`.opencode/missions/<team-id>/model-policy.json`. A deterministic complexity × risk
grid replaces cost/intelligence arbitration for these missions. Explicit model
overrides cannot bypass it; auto-dispatch and auto-scale wait for approval.

No particular planner or orchestrator profile is required. Project-specific
scoring floors, workflows and verification rules remain in the project. Requires
the public V2 command/model APIs; legacy `team_create` behavior is unchanged.
See [mission policy](docs/mission-policy.md), including the command-origin trust
limitation and revision/rollback guarantees.

### Legacy deterministic complexity/risk routing

Merge the supplied 17-candidate [catalogue](examples/ensemble.model-routing.json)
into your plugin `ensemble.json`. Supply optional integer `complexity` and
`risk` (0–100) directly to `team_spawn`, or on `team_tasks_add` entries that a
spawn claims through `claim_task`. Native reasoning efforts are transmitted as
variants, persisted across wakes, and treated as distinct scored candidates.

Selection is explicit model → task router → existing Ensemble configuration →
OpenCode default. The router selects the cheapest sufficient model and exposes
an eligible fallback, preferring another provider. It makes no LLM/JEV calls,
does not change review policy, and does not auto-retry on its fallback.
The cost rule is not provider load balancing. See [routing details](docs/model-routing.md)
and the opt-in [`ensemble-model-catalogue` maintenance skill](skills/ensemble-model-catalogue/SKILL.md).

### Mission-scoped classification

`team_create` detects compatible classification tools once and freezes the
protocol for the mission. Choose `classification.helperModel` explicitly for
JEV/x86 invocation, or `generalModel` for the tool-denied general classifier;
no model or fallback is activated implicitly. Internal scores remain **0–1**.
Unclassified tasks cannot be claimed or auto-dispatched.

`supervised` is the default; `mission_mode: "long_run"` continues independent
work within explicit retry/fallback and budget limits, stopping new admission
on critical budget or cleanup failures without aborting existing workers.
See [task classification](docs/task-classification.md) for configuration,
provenance, user-approved policy updates and restart recovery.

In both modes, routine implementation and coordination decisions stay with the
agents within the authorized phase and plan. A milestone, QA result or completed
worker does not require a new user go. Ask before an unapproved architectural
change or a change to the mission objective; explicit holds, permissions,
budgets, QA and initial/revised policy approval remain binding. Long-run decision
priorities are configured separately in the approved `autonomy` contract; see
[mission decision boundaries](docs/mission-policy.md#decisions-and-milestone-continuation-in-both-modes).

## Permission diagnostics

On V2, recognized permission/tool-access failures are recorded locally under
`~/.config/opencode/diagnostics/permissions/YYYY-MM-DD.jsonl`. Records identify the
session, known parent/agent/team, tool and catalogue namespace without retaining
tool arguments, raw errors or credentials. The read-only viewer distinguishes
permission refusals from user rejection, filesystem/remote authorization failures
and unavailable tools; it never changes rights or retries a failed action.

```sh
bun run diagnose:permissions -- --session ses_example --limit 25
```

See [permission diagnostics](docs/permission-diagnostics.md) for filters, JSON
export, privacy, partial-result warnings and limits of native event coverage.

## Best practices

- Start with 2-3 teammates. More agents means more coordination overhead.
- Give each teammate specific, self-contained tasks. Vague prompts produce vague results.
- Choose profiles and context transitions for the mission. Reuse relevant native research through a fork, continue a session through handoff, or start fresh when independence is useful.
- Use `worktree: false` for read-only agents (research, review, code analysis).
- Use `plan_approval: true` when the mission/project requires plan review. The teammate sends a plan and the lead approves before implementation; this is not automatically a new user go.
- Don't micromanage. Teammates message you when done or when they're blocked.
- Don't poll `team_status` in a loop. Wait for messages.

## Known limitations

- **Teammate messages may switch the lead's agent mode (v1).** When a teammate sends a message back to the lead, OpenCode can start the next prompt loop in build mode even if the lead was in plan/explore mode. Tracked upstream; the lead's mode restores when you send your next message. On V2, model selection is separate from agent selection; use an explicit spawn model only when an override is intended.
- **Session switching is opt-in (v2).** `team_view` reports the teammate's session ID by default; it switches the user's client only when asked for with `navigate: true` — agents never hijack the client unprompted. The live sidebar (terminal only) shows member status on every client's dashboard at `http://localhost:4747`.
- **Per-session shell env is unavailable (v2).** The v2 shell hook carries no session ID, so `ENSEMBLE_*` variables are not injected into teammate shells. Team identity travels in prompts and tool calls instead.
- **Native continuity has explicit boundaries (v2).** `compact_fork` requires a distinct idle source; cross-directory inheritance requires clean, matching Git HEADs. Lost native creation acknowledgements can leave resources whose IDs were never received; see the [recovery limits](docs/native-session-continuity.md#remaining-limits).
- **`/ensemble-mission prepare` uses an existing PM.** Its native child session appears in V2's active-work/subagent view, without becoming an executing Ensemble member. The command acknowledges the queued PM, then returns the result separately. The supervisor also reproduces its exact session ID as inline code in its reply: V2 Desktop turns that reference into an open-session button, including for an older independent or completed PM. Reply instructions do not inject assistant text or add a model turn. Runtime and adapter regression tests do not imply a full live PM/model smoke. See [preparation](docs/preparation.md).

## How this differs from Claude Code agent teams

Same coordination model (shared tasks, peer messaging, lead coordination) with some additions:

- **Git worktree isolation by default**: each teammate gets their own branch, no merge conflicts between parallel agents
- **System prompt injection**: the lead's system prompt is updated with team state so it stays aware across turns
- **Compaction safety**: team context is preserved when sessions get long
- **Team-aware shell environment**: `ENSEMBLE_TEAM`, `ENSEMBLE_MEMBER`, `ENSEMBLE_ROLE`, `ENSEMBLE_BRANCH`
- **Graceful shutdown**: teammates finish current work before stopping, with a force flag for emergencies
- **Plan approval mode**: review teammate plans before they write code
- **Works today as a plugin**: install and go, no upstream changes needed

## Development

```bash
bun install
bun run typecheck
bun test
bun run build
# Requires an OpenCode V2 executable; set OPENCODE_TEST_BIN if it is not on PATH.
bun run eval:continuity
```

See [CONTRIBUTING.md](./CONTRIBUTING.md) for development guidelines.

## License

MIT
