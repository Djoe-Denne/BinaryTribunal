import type { Database } from "./db"
export type CapacityOwnerKind = "legacy" | "scientific"
export type CapacityState = "reserved" | "effect_entered" | "held_ambiguous" | "converted" | "released"
/** Internal owner data, not native authority or a scientific proof. */
export interface CapacityOwner { id: string; teamId: string; ownerKind: CapacityOwnerKind; ownerKey: string; imageRef: string; memberName: string | null }
/** Revision-bound internal reference. Replaying it never permits another native allocation. */
export interface CapacityToken extends CapacityOwner { revision: number; state: CapacityState; allocationRef: string | null; sessionId: string | null; reason: string | null }
export interface CapacitySnapshot { ordinary: number; reservedEffects: number; used: number; maximum: number; remaining: number | null }
/** Positive linkage supplied by the trusted integration, not authenticated by a DTO. */
export interface LegacyAllocationMatch { allocationRef: string; sessionId: string; memberName: string; teamId: string }
interface Row { id: string; team_id: string; owner_kind: CapacityOwnerKind; owner_key: string; image_ref: string; revision: number; state: CapacityState; allocation_ref: string | null; session_id: string | null; member_name: string | null; reason: string | null }
function check(value: unknown, message: string): asserts value { if (!value) throw new Error(`capacity: ${message}`) }
function nonempty(value: unknown): asserts value is string { check(typeof value === "string" && value.trim().length > 0, "nonempty owner reference required") }
function count(value: unknown): asserts value is number { check(typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && !Object.is(value, -0), "nonnegative integer required") }
function owner(value: CapacityOwner): void {
  for (const v of [value.id, value.teamId, value.ownerKey, value.imageRef]) nonempty(v)
  check(value.ownerKind === "legacy" || value.ownerKind === "scientific", "unknown owner kind")
  if (value.ownerKind === "legacy") nonempty(value.memberName)
  else check(value.memberName === null, "scientific owner cannot target a recyclable member")
}
function token(r: Row): CapacityToken { return { id: r.id, teamId: r.team_id, ownerKind: r.owner_kind, ownerKey: r.owner_key, imageRef: r.image_ref, memberName: r.member_name, revision: r.revision, state: r.state, allocationRef: r.allocation_ref, sessionId: r.session_id, reason: r.reason } }
function find(db: Database, id: string): Row { const r = db.query("SELECT * FROM team_capacity_reservation WHERE id=?").get(id) as Row | null; check(r, "reservation not found"); return r }
function sameOwner(r: Row, o: CapacityOwner): boolean { return r.id === o.id && r.team_id === o.teamId && r.owner_kind === o.ownerKind && r.owner_key === o.ownerKey && r.image_ref === o.imageRef && r.member_name === o.memberName }
function current(db: Database, t: CapacityToken): Row {
  owner(t); count(t.revision)
  const r = find(db, t.id)
  check(sameOwner(r, t) && r.revision === t.revision && r.state === t.state && r.allocation_ref === t.allocationRef && r.session_id === t.sessionId && r.reason === t.reason, "stale or foreign reservation token")
  return r
}
function transaction<T>(db: Database, work: () => T): T {
  // BEGIN is outside rollback ownership. Failure must leave any foreign transaction untouched.
  db.exec("BEGIN IMMEDIATE")
  try { const result = work(); db.exec("COMMIT"); return result }
  catch (error) { db.exec("ROLLBACK"); throw error }
}
function update(db: Database, r: Row, state: CapacityState, allocation: string | null, session: string | null, reason: string | null): CapacityToken {
  const changed = db.run("UPDATE team_capacity_reservation SET state=?,allocation_ref=?,session_id=?,reason=?,revision=revision+1 WHERE id=? AND team_id=? AND owner_kind=? AND owner_key=? AND image_ref=? AND revision=? AND state=?", [state, allocation, session, reason, r.id, r.team_id, r.owner_kind, r.owner_key, r.image_ref, r.revision, r.state])
  check(changed.changes === 1, "reservation CAS conflict")
  return token(find(db, r.id))
}
/** Read ordinary membership and reserved effects in one SQLite statement/snapshot. */
export function readCapacity(db: Database, teamId: string, maximum: number): CapacitySnapshot {
  nonempty(teamId); count(maximum)
  const r = db.query(`SELECT
    (SELECT COUNT(*) FROM team_member WHERE team_id=? AND status NOT IN ('shutdown','error')) AS ordinary,
    (SELECT COUNT(*) FROM team_capacity_reservation WHERE team_id=? AND state IN ('reserved','effect_entered','held_ambiguous')) AS reservedEffects`).get(teamId, teamId) as { ordinary: number; reservedEffects: number }
  const used = r.ordinary + r.reservedEffects
  return { ...r, used, maximum, remaining: maximum === 0 ? null : Math.max(0, maximum - used) }
}
/** Atomically check and reserve; exact replay returns current state, never a new entry permit. */
export function reserveCapacity(db: Database, teamId: string, maximum: number, input: CapacityOwner): CapacityToken {
  owner(input); nonempty(teamId); count(maximum)
  const o = { ...input }; check(o.teamId === teamId, "team mismatch")
  return transaction(db, () => {
    const prior = db.query("SELECT * FROM team_capacity_reservation WHERE team_id=? AND owner_kind=? AND owner_key=?").get(teamId, o.ownerKind, o.ownerKey) as Row | null
    check((db.query("SELECT status FROM team WHERE id=?").get(teamId) as { status: string } | null)?.status === "active", "team is not active")
    if (prior) { check(sameOwner(prior, o), "reservation replay conflict"); return token(prior) }
    if (o.memberName !== null) check(!db.query("SELECT id FROM team_capacity_reservation WHERE team_id=? AND member_name=? AND state IN ('reserved','effect_entered','held_ambiguous')").get(teamId, o.memberName), "member name has a held capacity demand")
    const snapshot = readCapacity(db, teamId, maximum)
    check(maximum === 0 || snapshot.used < maximum, "capacity exhausted")
    db.run("INSERT INTO team_capacity_reservation (id,team_id,owner_kind,owner_key,image_ref,revision,state,allocation_ref,session_id,member_name,reason) VALUES (?,?,?,?,?,1,'reserved',NULL,NULL,?,NULL)", [o.id, teamId, o.ownerKind, o.ownerKey, o.imageRef, o.memberName])
    return token(find(db, o.id))
  })
}
/** Fix the allocation correlation before entry; a repeated call is rejected, not replayed. */
export function markEffectEntry(db: Database, t: CapacityToken, allocationRef: string): CapacityToken {
  nonempty(allocationRef)
  return transaction(db, () => {
    const r = current(db, t); check(r.state === "reserved" && r.allocation_ref === null, "effect already entered or reservation closed")
    check(!db.query("SELECT id FROM team_capacity_reservation WHERE team_id=? AND allocation_ref=? AND id<>?").get(r.team_id, allocationRef, r.id), "allocation correlation already owned")
    return update(db, r, "effect_entered", allocationRef, null, null)
  })
}
/** Preserve possible entry without authorizing retry, cleanup or release. */
export function holdAmbiguous(db: Database, t: CapacityToken, reason: string): CapacityToken {
  nonempty(reason)
  return transaction(db, () => { const r = current(db, t); check(r.state === "effect_entered" || r.state === "held_ambiguous", "no entered effect to hold"); return update(db, r, "held_ambiguous", r.allocation_ref, r.session_id, reason) })
}
/** Convert positive legacy linkage atomically with insertion; the trusted callback is not a sandbox. */
export function convertToLegacyMember(db: Database, t: CapacityToken, input: LegacyAllocationMatch, insertMember: (db: Database) => unknown): CapacityToken {
  const m = { ...input }; [m.teamId, m.memberName, m.sessionId, m.allocationRef].forEach(nonempty)
  return transaction(db, () => {
    const r = current(db, t)
    check(r.owner_kind === "legacy" && (r.state === "effect_entered" || r.state === "held_ambiguous"), "legacy entered reservation required")
    check(m.teamId === r.team_id && m.memberName === r.member_name && m.allocationRef === r.allocation_ref, "foreign allocation linkage")
    check(!db.query("SELECT name FROM team_member WHERE (team_id=? AND name=?) OR session_id=?").get(m.teamId, m.memberName, m.sessionId), "member/session already exists")
    check(!db.query("SELECT id FROM team_capacity_reservation WHERE id<>? AND session_id=?").get(r.id, m.sessionId), "session already linked")
    const result = insertMember(db)
    check(!(result !== null && (typeof result === "object" || typeof result === "function") && typeof (result as { then?: unknown }).then === "function"), "async insertion callback forbidden")
    const member = db.query("SELECT team_id,name,session_id,status FROM team_member WHERE team_id=? AND name=?").get(m.teamId, m.memberName) as { team_id: string; name: string; session_id: string; status: string } | null
    check(member && member.team_id === m.teamId && member.name === m.memberName && member.session_id === m.sessionId && !["shutdown", "error"].includes(member.status), "inserted member readback mismatch")
    check((db.query("SELECT COUNT(*) AS n FROM team_member WHERE session_id=?").get(m.sessionId) as { n: number }).n === 1, "session linkage ambiguous")
    // Recheck after trusted synchronous insertion, never overwrite a callback-side state change.
    current(db, t)
    return update(db, r, "converted", r.allocation_ref, m.sessionId, null)
  })
}
/** Refuse archive/close while an allocation slot remains owned, without native inference. */
export function assertNoHeldCapacity(db: Database, teamId: string): void {
  check(!db.query("SELECT id FROM team_capacity_reservation WHERE team_id=? AND state IN ('reserved','effect_entered','held_ambiguous') LIMIT 1").get(teamId), "capacity reservation still held")
}
/** Refuse purge for all capacity audit records, including converted and released. */
export function assertNoCapacityRecords(db: Database, teamId: string): void {
  check(!db.query("SELECT id FROM team_capacity_reservation WHERE team_id=? LIMIT 1").get(teamId), "capacity reservation audit prevents purge")
}
/** Release only a legacy reservation before entry. No scientific or timeout release exists. */
export function releaseLegacyBeforeEntry(db: Database, t: CapacityToken, reason: string): CapacityToken {
  nonempty(reason)
  return transaction(db, () => { const r = current(db, t); check(r.owner_kind === "legacy" && r.state === "reserved" && r.allocation_ref === null && r.session_id === null, "release forbidden after entry or for scientific owner"); return update(db, r, "released", null, null, reason) })
}
