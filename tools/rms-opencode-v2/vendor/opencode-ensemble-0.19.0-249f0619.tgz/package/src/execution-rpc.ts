import { Rpc } from "@opencode/plugin/rpc"
const operations = ["capabilities", "submit", "observe", "reconcile", "control"] as const
function envelope(operation: typeof operations[number], response: boolean) {
  const binding = response ? ["requestRef"] : []
  return { type: "object" as const, properties: {
    protocol: { type: "string" as const, enum: ["ensemble-execution-protocol-v2"] },
    operation: { type: "string" as const, enum: [operation] },
    ...(response ? { requestRef: { type: "object" as const } } : {}), scope: { type: "object" as const }, body: { type: "object" as const },
  }, required: ["protocol", "operation", ...binding, "scope", "body"], additionalProperties: false }
}
function method(operation: typeof operations[number]) { return { input: envelope(operation, false), output: envelope(operation, true) } }
/** Portable public definition only. No handlers, registration, setup or side effects. */
export const ExecutionRpcV2 = Rpc.define({
  id: "ensemble.execution.v2",
  methods: { capabilities: method("capabilities"), submit: method("submit"), observe: method("observe"), reconcile: method("reconcile"), control: method("control") },
  events: {},
})
